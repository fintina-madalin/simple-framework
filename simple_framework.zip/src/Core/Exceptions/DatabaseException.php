<?php

namespace App\Core\Exceptions;

class DatabaseException extends \Exception
{

}