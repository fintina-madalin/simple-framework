<?php

namespace App\Core\Exceptions;

class ViewException extends \Exception
{

}