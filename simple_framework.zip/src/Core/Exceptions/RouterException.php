<?php

namespace App\Core\Exceptions;

class RouterException extends \Exception
{

}