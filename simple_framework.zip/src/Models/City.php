<?php

namespace App\Models;

use App\Core\Model;

class City extends Model
{
    protected static string $table = 'cities';
}