
INSERT INTO cities (name) VALUES ('San Francisco');
INSERT INTO cities (name) VALUES ('Seattle');
INSERT INTO cities (name) VALUES ('Boston');


INSERT INTO contacts (last_name, first_name, email, street, zip_code, city_id)
VALUES ('Doe', 'John', 'john.doe@example.com', '123 Main St', '12345', 1);
INSERT INTO contacts (last_name, first_name, email, street, zip_code, city_id)
VALUES ('Smith', 'Alice', 'alice.smith@example.com', '456 Elm St', '67890', 2);
INSERT INTO contacts (last_name, first_name, email, street, zip_code, city_id)
VALUES ('Johnson', 'Bob', 'bob.johnson@example.com', '789 Maple St', '54321', 3);
